
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		frame_1
	 *	@date 		Tuesday 11th of April 2023 09:57:35 PM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;

public class frame_1_activity extends Activity {

	
	private View _bg__frame_1_ek2;
	private View rectangle_1;
	private View ellipse_1;
	private View ellipse_2;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.frame_1);

		
		_bg__frame_1_ek2 = (View) findViewById(R.id._bg__frame_1_ek2);
		rectangle_1 = (View) findViewById(R.id.rectangle_1);
		ellipse_1 = (View) findViewById(R.id.ellipse_1);
		ellipse_2 = (View) findViewById(R.id.ellipse_2);
	
		
		//custom code goes here
	
	}
}
	
	